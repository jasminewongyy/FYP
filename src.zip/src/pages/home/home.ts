import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

import {GrowthTrackerPage} from '../growth-tracker/growth-tracker';
import {CalendarPage} from '../calendar/calendar';
import {CareGuidePage} from '../care-guide/care-guide';
import {OrientationPage} from '../orientation/orientation';
import {DiaryPage} from '../diary/diary';
import {SettingsPage} from '../settings/settings';
import {GetStartedPage} from '../get-started/get-started';

import {Storage} from '@ionic/storage';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})


export class HomePage {


  constructor(public navCtrl: NavController, public storage: Storage) {

  }

  goToGrowthTracker() {
    this.navCtrl.push(GrowthTrackerPage);
  }
  goToCalendar() {
    this.navCtrl.push(CalendarPage);
  }
  goToCareGuide() {
    this.navCtrl.push(CareGuidePage);
  }

  goToOrientation() {
    this.navCtrl.push(OrientationPage);
  }
  goToDiary() {
    this.navCtrl.push(DiaryPage);
  }
  goToSettings() {
    this.navCtrl.push(SettingsPage);
  }
  goToGetStarted() {
    this.navCtrl.push(GetStartedPage);
  }

  StorageSet() {
    this.storage.set('name','jasmine');
    console.log('name is set');
    console.log(name)
  }

  StorageGet() {
    this.storage.get('name').then((data) => {
      console.log ('your name is ', data);
    });
  }

}
